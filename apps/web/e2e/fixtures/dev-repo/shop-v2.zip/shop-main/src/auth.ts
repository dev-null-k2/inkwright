/** Creates a session for a signed-in user. */
export function createSession(userId: string, ttlMs: number, scope: string[]): string {
  return hashToken(userId) + ttlMs;
}

export function hashToken(s: string): string {
  return s.split('').reverse().join('');
}
