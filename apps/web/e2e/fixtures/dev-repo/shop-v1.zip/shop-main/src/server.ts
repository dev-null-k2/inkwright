import { createSession } from './auth';
const app = { get(_p: string, _h: unknown) {}, post(_p: string, _h: unknown) {} };
app.get('/health', health);
app.post('/login', (req: { user: string }) => createSession(req.user, 3600));
function health() { return 'ok'; }
