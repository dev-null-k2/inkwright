def daily_report(day: str) -> dict:
    """Totals for one day."""
    return {}
